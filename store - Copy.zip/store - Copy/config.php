<?php
define('BASEURL', $_SERVER['DOCUMENT_ROOT'].'/store/');
/*define('CART_COOKIE','SBwi72UCklwiqzz2');
define('CART_COOKIE_EXPIRE',time() + (86400 *30));
define('TAXRATE',0.000);*/
